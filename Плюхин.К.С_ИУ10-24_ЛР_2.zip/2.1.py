import turtle
from random import *
turtle.shape('turtle')
while 1==1:
    f=randint(0,50)
    n=randint(0,360)
    turtle.left(n)
    turtle.forward(f)
